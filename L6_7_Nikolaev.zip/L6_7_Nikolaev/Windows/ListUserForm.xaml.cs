﻿using L6_7_Nikolaev.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace L6_7_Nikolaev.Windows
{
    /// <summary>
    /// Логика взаимодействия для ListUserForm.xaml
    /// </summary>
    public partial class ListUserForm : Window
    {
        public ListUserForm()
        {
            InitializeComponent();
            list = new ObservableCollection<User>
            {
                new User()
                {
                    Name = "Вася",
                    SurName = "Василий",
                    Role = "Пользователь",
                    Login = "12345@123",
                    Password= "Password",
                },
                new User()
                {
                    Name = "Вася",
                    SurName = "Василий",
                    Role = "Пользователь",
                    Login = "12345@123",
                    Password= "Password",
                },
            };
            gridData.ItemsSource = List;
            
        }
        private ObservableCollection<User> list;
        public ObservableCollection<User> List 
        { get 
            { 
                return list; 
            } 
            set
            {
                list = value;
            } 
        }


    }
}

/* <local1:User Login="SlavaNik" Name="Slava" Password="12345" Role="Admin" SurName="Nikolaev"/>
            <local1:User Login="Sasha" Name="Sasha" Password="Sasha" Role="User" SurName="Malle"/>
            <local1:User Login="Pinok" Name="Peta" Password="Pinok1" Role="User" SurName="Tolking"/>
*/