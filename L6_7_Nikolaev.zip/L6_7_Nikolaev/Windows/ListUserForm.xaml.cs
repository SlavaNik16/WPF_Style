﻿using L6_7_Nikolaev.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace L6_7_Nikolaev.Windows
{
    /// <summary>
    /// Логика взаимодействия для ListUserForm.xaml
    /// </summary>
    public partial class ListUserForm : Window
    {
        public ListUserForm()
        {
            InitializeComponent();
            
        }



    }
}
